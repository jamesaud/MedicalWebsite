--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.5
-- Dumped by pg_dump version 9.5.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: medweb
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE auth_group OWNER TO medweb;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: medweb
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_id_seq OWNER TO medweb;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medweb
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: medweb
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_group_permissions OWNER TO medweb;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: medweb
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_permissions_id_seq OWNER TO medweb;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medweb
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: medweb
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE auth_permission OWNER TO medweb;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: medweb
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_permission_id_seq OWNER TO medweb;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medweb
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: medweb
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE django_admin_log OWNER TO medweb;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: medweb
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin_log_id_seq OWNER TO medweb;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medweb
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: medweb
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE django_content_type OWNER TO medweb;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: medweb
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_content_type_id_seq OWNER TO medweb;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medweb
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: medweb
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE django_migrations OWNER TO medweb;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: medweb
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_migrations_id_seq OWNER TO medweb;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medweb
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: medweb
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE django_session OWNER TO medweb;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: medweb
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE django_site OWNER TO medweb;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: medweb
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_site_id_seq OWNER TO medweb;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medweb
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: homepage_evaluation; Type: TABLE; Schema: public; Owner: medweb
--

CREATE TABLE homepage_evaluation (
    person_id integer NOT NULL,
    group_name character varying(255) NOT NULL,
    message character varying(2000) NOT NULL,
    call_time timestamp with time zone,
    current_system character varying(255) NOT NULL,
    ehr_support_vendors integer,
    ehr_support_personnel integer,
    ehr_likes character varying(2000) NOT NULL,
    ehr_dislikes character varying(2000) NOT NULL,
    hr_providers integer,
    hr_it_staff integer,
    hr_other_staff integer,
    ehr_providers integer,
    ehr_mas integer,
    ehr_receptionists integer,
    rcm_billers integer,
    rcm_coders integer,
    rcm_scribes integer,
    rcm_collectors integer,
    clearinghouse character varying(512) NOT NULL,
    billing_company character varying(512) NOT NULL,
    days_to_collect integer,
    percent_ars double precision,
    available_rooms integer,
    revenue_labs integer,
    doctors_recruit character varying(2000) NOT NULL,
    total_revenue double precision,
    referral character varying(255) NOT NULL,
    monthly_newsletter boolean NOT NULL,
    ehr_admin integer,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE homepage_evaluation OWNER TO medweb;

--
-- Name: homepage_person; Type: TABLE; Schema: public; Owner: medweb
--

CREATE TABLE homepage_person (
    id integer NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    home_phone character varying(15),
    office_phone character varying(15),
    "position" character varying(255) NOT NULL,
    contacted boolean NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    notes text NOT NULL
);


ALTER TABLE homepage_person OWNER TO medweb;

--
-- Name: homepage_person_id_seq; Type: SEQUENCE; Schema: public; Owner: medweb
--

CREATE SEQUENCE homepage_person_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE homepage_person_id_seq OWNER TO medweb;

--
-- Name: homepage_person_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medweb
--

ALTER SEQUENCE homepage_person_id_seq OWNED BY homepage_person.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: medweb
--

CREATE TABLE users_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE users_user OWNER TO medweb;

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: medweb
--

CREATE TABLE users_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE users_user_groups OWNER TO medweb;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: medweb
--

CREATE SEQUENCE users_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_user_groups_id_seq OWNER TO medweb;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medweb
--

ALTER SEQUENCE users_user_groups_id_seq OWNED BY users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: medweb
--

CREATE SEQUENCE users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_user_id_seq OWNER TO medweb;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medweb
--

ALTER SEQUENCE users_user_id_seq OWNED BY users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: medweb
--

CREATE TABLE users_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE users_user_user_permissions OWNER TO medweb;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: medweb
--

CREATE SEQUENCE users_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_user_user_permissions_id_seq OWNER TO medweb;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: medweb
--

ALTER SEQUENCE users_user_user_permissions_id_seq OWNED BY users_user_user_permissions.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY homepage_person ALTER COLUMN id SET DEFAULT nextval('homepage_person_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY users_user ALTER COLUMN id SET DEFAULT nextval('users_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY users_user_groups ALTER COLUMN id SET DEFAULT nextval('users_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('users_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: medweb
--

COPY auth_group (id, name) FROM stdin;
1	Edit_Person_And_Evaluation
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medweb
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, true);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: medweb
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
1	1	26
2	1	22
3	1	23
4	1	25
5	1	10
6	1	11
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medweb
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 6, true);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: medweb
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can add group	2	add_group
5	Can change group	2	change_group
6	Can delete group	2	delete_group
7	Can add content type	3	add_contenttype
8	Can change content type	3	change_contenttype
9	Can delete content type	3	delete_contenttype
10	Can add session	4	add_session
11	Can change session	4	change_session
12	Can delete session	4	delete_session
13	Can add site	5	add_site
14	Can change site	5	change_site
15	Can delete site	5	delete_site
16	Can add log entry	6	add_logentry
17	Can change log entry	6	change_logentry
18	Can delete log entry	6	delete_logentry
19	Can add user	7	add_user
20	Can change user	7	change_user
21	Can delete user	7	delete_user
22	Can add person	8	add_person
23	Can change person	8	change_person
24	Can delete person	8	delete_person
25	Can add evaluation	9	add_evaluation
26	Can change evaluation	9	change_evaluation
27	Can delete evaluation	9	delete_evaluation
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medweb
--

SELECT pg_catalog.setval('auth_permission_id_seq', 27, true);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: medweb
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2016-11-25 18:53:05.362106+00	1	Edit_Person_And_Evaluation	1	Added.	2	1
2	2016-11-25 18:53:07.194386+00	1	Edit_Person_And_Evaluation	2	No fields changed.	2	1
3	2016-11-25 18:53:50.512311+00	2	test	1	Added.	7	1
4	2016-11-25 18:54:16.846717+00	2	test	3		7	1
5	2016-11-25 19:39:03.950945+00	59	TEST1test2	2	Deleted evaluation "Evaluation of: TEST1test2".	8	1
6	2016-11-25 19:56:57.831069+00	60	JAAUD	3		8	1
7	2016-11-25 20:31:30.806634+00	3	test	1	Added.	7	1
8	2016-11-25 20:31:58.710423+00	3	test	2	Changed name, first_name, last_name, email, is_staff and groups.	7	1
9	2016-11-26 04:08:05.184717+00	77	hello world	2	Changed contacted.	8	1
10	2016-11-26 17:11:05.319243+00	80	aa ss	2	Changed call_time for evaluation "Evaluation of: aa ss".	8	1
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medweb
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 10, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: medweb
--

COPY django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	contenttypes	contenttype
4	sessions	session
5	sites	site
6	admin	logentry
7	users	user
8	homepage	person
9	homepage	evaluation
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medweb
--

SELECT pg_catalog.setval('django_content_type_id_seq', 9, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: medweb
--

COPY django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2016-11-11 01:24:19.048141+00
2	contenttypes	0002_remove_content_type_name	2016-11-11 01:24:19.065907+00
3	auth	0001_initial	2016-11-11 01:24:19.119094+00
4	auth	0002_alter_permission_name_max_length	2016-11-11 01:24:19.132228+00
5	auth	0003_alter_user_email_max_length	2016-11-11 01:24:19.148713+00
6	auth	0004_alter_user_username_opts	2016-11-11 01:24:19.168388+00
7	auth	0005_alter_user_last_login_null	2016-11-11 01:24:19.179797+00
8	auth	0006_require_contenttypes_0002	2016-11-11 01:24:19.185324+00
9	users	0001_initial	2016-11-11 01:24:19.247059+00
10	admin	0001_initial	2016-11-11 01:24:19.293767+00
11	admin	0002_logentry_remove_auto_add	2016-11-11 01:24:19.314246+00
12	auth	0007_alter_validators_add_error_messages	2016-11-11 01:24:19.327668+00
13	sessions	0001_initial	2016-11-11 01:24:19.344989+00
14	sites	0001_initial	2016-11-11 01:24:19.356081+00
15	sites	0002_set_site_domain_and_name	2016-11-11 01:24:19.367022+00
16	sites	0003_auto_20160815_0615	2016-11-11 01:24:19.380349+00
17	users	0002_auto_20160815_0615	2016-11-11 01:24:19.413498+00
18	homepage	0001_initial	2016-11-11 02:04:11.603587+00
19	homepage	0002_auto_20161122_2132	2016-11-22 21:33:44.949601+00
20	homepage	0003_auto_20161123_1808	2016-11-23 18:08:23.663512+00
21	homepage	0004_auto_20161123_1814	2016-11-23 18:14:24.053953+00
22	homepage	0005_auto_20161124_0223	2016-11-24 02:24:08.431874+00
23	homepage	0006_auto_20161124_0531	2016-11-24 05:31:21.561468+00
24	homepage	0007_auto_20161125_1952	2016-11-25 19:53:20.478852+00
25	homepage	0008_auto_20161125_1957	2016-11-25 19:57:59.436427+00
26	homepage	0009_person_notes	2016-11-26 17:03:25.890534+00
27	homepage	0010_auto_20161126_1705	2016-11-26 17:05:55.810522+00
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medweb
--

SELECT pg_catalog.setval('django_migrations_id_seq', 27, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: medweb
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
beftkljiegon7gid9zzd2vbmm0qbm6ny	ZmUyNzA5OTY4MzRmZGNiYmMyNzA5YjhiNTNlOTE5NmVkMDM4ZjE1MTp7InBhc3N3b3JkIjoiZGVmYXVsdCJ9	2016-12-08 01:50:10.119309+00
ksr7xn2cajwguhuacj68mxmbyj5o01li	OGZiMDQ0ZWE2YjRlMzk0YTBmZTE3OWJmMjlhNTI2NzNiYjJlNWIxMDp7Il9hdXRoX3VzZXJfaGFzaCI6ImM1ZWYwYmFmZWJiNmE3ZTVmNGI4NjZjZGU2MzNiNjE2NGZmNjhmYWEiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIzIn0=	2016-12-09 20:32:21.030146+00
h8uoxgi8ljh5umnyb0ixheudx0w7oxuh	NjQwMjIwMGFjMjFkM2I5OTA3NzY0NDE0N2FlZjRkZTQzOWUzODdlZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJwZXJzb25faWQiOjgwLCJfYXV0aF91c2VyX2hhc2giOiJkNWYwYjJkMWZkMGRhNmMyNzMyZDI2ZTI5MzlkM2EyNmY2NjYyNTNjIiwicGFzc3dvcmQiOiJzeW5lcmd5NjUxIn0=	2016-12-10 04:56:25.56127+00
r1azi605fby4e7npmz3mmxgcylesjym8	YTU4NTk3YWFhNDZjYjVkMmRiM2RhNTQ2OTJlNTUzMmU0MzU4ZGI3ZDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwicGVyc29uX2lkIjo4MiwicGFzc3dvcmQiOiJzeW5lcmd5NjUxIiwiX2F1dGhfdXNlcl9oYXNoIjoiYzVlZjBiYWZlYmI2YTdlNWY0Yjg2NmNkZTYzM2I2MTY0ZmY2OGZhYSIsIl9hdXRoX3VzZXJfaWQiOiIzIn0=	2016-12-11 01:50:00.330835+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: medweb
--

COPY django_site (id, domain, name) FROM stdin;
1	example.com	Medical Website
\.


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medweb
--

SELECT pg_catalog.setval('django_site_id_seq', 1, false);


--
-- Data for Name: homepage_evaluation; Type: TABLE DATA; Schema: public; Owner: medweb
--

COPY homepage_evaluation (person_id, group_name, message, call_time, current_system, ehr_support_vendors, ehr_support_personnel, ehr_likes, ehr_dislikes, hr_providers, hr_it_staff, hr_other_staff, ehr_providers, ehr_mas, ehr_receptionists, rcm_billers, rcm_coders, rcm_scribes, rcm_collectors, clearinghouse, billing_company, days_to_collect, percent_ars, available_rooms, revenue_labs, doctors_recruit, total_revenue, referral, monthly_newsletter, ehr_admin, created, modified) FROM stdin;
61		hello	\N		\N	\N	hello	wordl	4	5	5	54	544	54	45	45	45	54	clearing	billing	20	30	45	54	2-3 more	324		f	45	2016-11-25 19:58:26.838525+00	2016-11-25 19:59:00.02495+00
75		msse	\N		\N	\N			\N	\N	\N	\N	\N	\N	\N	\N	\N	\N			\N	\N	\N	\N		\N		f	\N	2016-11-25 22:19:30.871304+00	2016-11-25 22:19:30.872446+00
76		asdafads	2016-11-25 17:21:00+00		\N	\N			\N	\N	\N	\N	\N	\N	\N	\N	\N	\N			\N	\N	\N	\N		\N		f	\N	2016-11-25 22:21:47.244274+00	2016-11-25 22:21:47.245655+00
77	group  name	hello world	2016-11-25 23:05:00+00		\N	\N			\N	\N	\N	\N	\N	\N	\N	\N	\N	\N			\N	\N	\N	\N		\N		f	\N	2016-11-26 04:05:55.039912+00	2016-11-26 04:05:55.042399+00
78	ja	hello	2016-11-25 23:09:00+00		\N	\N			\N	\N	\N	\N	\N	\N	\N	\N	\N	\N			\N	\N	\N	\N		\N		f	\N	2016-11-26 04:10:00.625398+00	2016-11-26 04:10:00.628436+00
79	3	hello	2016-11-25 23:13:00+00	type4	4	4	like	dislike	3	4	4	4	4	34	324	23423423	2	\N	fdas	ewr	3	34	4	4	4	234234234		f	234	2016-11-26 04:13:48.315558+00	2016-11-26 04:16:29.101742+00
80	34		2016-11-25 23:56:13+00		\N	\N			\N	\N	\N	\N	\N	\N	\N	\N	\N	\N			\N	\N	\N	\N		\N		f	\N	2016-11-26 04:56:25.556788+00	2016-11-26 17:11:05.305213+00
81	fdad	setrtsre	2016-11-26 12:45:00+00		\N	\N			\N	\N	\N	\N	\N	\N	\N	\N	\N	\N			\N	\N	\N	\N		\N	type1, , ,	f	\N	2016-11-26 17:45:16.393612+00	2016-11-26 17:45:46.340721+00
82	34343	hello	2016-11-27 02:50:00+00		\N	\N			\N	\N	\N	\N	\N	\N	\N	\N	\N	\N			\N	\N	\N	\N		\N		f	\N	2016-11-27 01:50:00.322448+00	2016-11-27 01:50:00.326308+00
\.


--
-- Data for Name: homepage_person; Type: TABLE DATA; Schema: public; Owner: medweb
--

COPY homepage_person (id, first_name, last_name, email, home_phone, office_phone, "position", contacted, created, modified, notes) FROM stdin;
61	Jasem	er	erj@fm.com	we	343-434-3434	ewr	f	2016-11-25 19:58:26.791519+00	2016-11-25 19:58:26.791558+00	
62	JAMES	Aud	jamesaud@gmail.com	343-434-34344	343-434-34343	343434343	f	2016-11-25 21:19:03.245285+00	2016-11-25 21:19:03.245309+00	
63	test	test	test@test.com		343-434-343434	test	f	2016-11-25 21:21:07.56736+00	2016-11-25 21:21:07.567402+00	
64	JA	t	jamesaud@gmail.com		343-434-34343	titl	f	2016-11-25 21:28:09.720482+00	2016-11-25 21:28:09.720506+00	
65	Ja	Au	jamesaud@gmail.com		434-343-4343	titl	f	2016-11-25 21:31:26.967044+00	2016-11-25 21:31:26.967107+00	
68	j	AU	jamesaud@gmail.com		343-434-34343	34343	f	2016-11-25 21:43:48.002748+00	2016-11-25 21:43:48.002774+00	
69	A	e	jamesaud@gmail.com		334-353-45345	e	f	2016-11-25 21:46:54.10636+00	2016-11-25 21:46:54.106431+00	
72	K	e	jamesaud@gmail.com		342-342-3423	k	f	2016-11-25 21:59:24.328719+00	2016-11-25 21:59:24.328745+00	
73	Ja	Au	jamesaud@gmail.com		343-434-3433	j	f	2016-11-25 22:15:17.223961+00	2016-11-25 22:15:17.223999+00	
74	mytest	test	tes@test.com		234-234-234324	test	f	2016-11-25 22:16:05.242209+00	2016-11-25 22:16:05.242238+00	
75	JA	au	jamesaud@gmail.com			j	f	2016-11-25 22:18:04.674641+00	2016-11-25 22:18:04.67467+00	
76	j	a	jamesaud@gmail.com		453-453-4534	re	f	2016-11-25 22:21:47.220666+00	2016-11-25 22:21:47.220691+00	
77	hello	world	test@test.com	343-434-3443	343-432-4233	aa	t	2016-11-26 04:05:55.006717+00	2016-11-26 04:08:05.177258+00	
78	sruthi	james	jamesaud@gmail.com		343-242-34324	position	f	2016-11-26 04:10:00.604305+00	2016-11-26 04:10:00.604342+00	
79	JA	wer	jamesaud@gmail.com	43	333-333-3333	324	f	2016-11-26 04:13:48.280451+00	2016-11-26 04:13:48.280502+00	
80	aa	ss	synergyplusjames@gmail.com		243-242-3423423	erwer	f	2016-11-26 04:56:25.544591+00	2016-11-26 17:11:05.287414+00	
81	T1	t2	r@h.com		432-342-34234	er	f	2016-11-26 17:45:16.37191+00	2016-11-26 17:45:16.371977+00	
82	mytest1	mytest2	james@james.com	phone	433-343-2432	title	f	2016-11-27 01:50:00.302712+00	2016-11-27 01:50:00.302747+00	
\.


--
-- Name: homepage_person_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medweb
--

SELECT pg_catalog.setval('homepage_person_id_seq', 82, true);


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: medweb
--

COPY users_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, name) FROM stdin;
1	pbkdf2_sha256$24000$pENeFfTmXpwZ$MGqphHj5SyXpr07iA3GAXbxJI38Q+lDu1D5VrdBtuyI=	2016-11-26 04:06:51.465796+00	t	james			jamesaud@gmail.com	t	t	2016-11-25 18:29:46.229285+00	
3	pbkdf2_sha256$24000$Bkp6fYdHP2IA$qwJxGG/ApPZsfdNEQxUdYy9jHW22URJ6axX+eCOmd+w=	2016-11-26 04:40:05.124883+00	f	test	test	test	test@test.com	t	t	2016-11-25 20:31:30+00	test
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: medweb
--

COPY users_user_groups (id, user_id, group_id) FROM stdin;
1	3	1
\.


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medweb
--

SELECT pg_catalog.setval('users_user_groups_id_seq', 1, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medweb
--

SELECT pg_catalog.setval('users_user_id_seq', 3, true);


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: medweb
--

COPY users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: medweb
--

SELECT pg_catalog.setval('users_user_user_permissions_id_seq', 1, false);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: homepage_evaluation_pkey; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY homepage_evaluation
    ADD CONSTRAINT homepage_evaluation_pkey PRIMARY KEY (person_id);


--
-- Name: homepage_person_pkey; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY homepage_person
    ADD CONSTRAINT homepage_person_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups_user_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions_user_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: medweb
--

CREATE INDEX auth_group_name_a6ea08ec_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: medweb
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: medweb
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: medweb
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: medweb
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: medweb
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: medweb
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: medweb
--

CREATE INDEX django_session_session_key_c0390e0f_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: medweb
--

CREATE INDEX django_site_domain_a2e37b91_like ON django_site USING btree (domain varchar_pattern_ops);


--
-- Name: users_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: medweb
--

CREATE INDEX users_user_groups_0e939a4f ON users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: medweb
--

CREATE INDEX users_user_groups_e8701ad4 ON users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: medweb
--

CREATE INDEX users_user_user_permissions_8373b171 ON users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: medweb
--

CREATE INDEX users_user_user_permissions_e8701ad4 ON users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: medweb
--

CREATE INDEX users_user_username_06e46fe6_like ON users_user USING btree (username varchar_pattern_ops);


--
-- Name: auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_content_type_id_c4bce8eb_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_content_type_id_c4bce8eb_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: homepage_evaluation_person_id_25cfea4a_fk_homepage_person_id; Type: FK CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY homepage_evaluation
    ADD CONSTRAINT homepage_evaluation_person_id_25cfea4a_fk_homepage_person_id FOREIGN KEY (person_id) REFERENCES homepage_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_pe_permission_id_0b93982e_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY users_user_user_permissions
    ADD CONSTRAINT users_user_user_pe_permission_id_0b93982e_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: medweb
--

ALTER TABLE ONLY users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

